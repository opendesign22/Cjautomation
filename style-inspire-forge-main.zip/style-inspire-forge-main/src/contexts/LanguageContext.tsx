
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'fr' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation dictionaries
const translations: Record<Language, Record<string, string>> = {
  fr: {
    // Navbar
    'nav.expertise': 'Expertise',
    'nav.energy-solutions': 'Solutions Énergétiques',
    'nav.about': 'Qui sommes-nous',
    'nav.references': 'Références',
    'nav.blog': 'Blog',
    'nav.contact': 'Contact',
    'nav.contact-us': 'Contactez-nous',
    'nav.career': 'Carrières',
    
    // Hero Section
    'hero.title': 'Automatisme industriel et solutions sur mesure',
    'hero.subtitle': 'Partenaire fiable pour toutes industries. Intégrateur de solutions sur mesure en électricité et automatisme.',
    'hero.cta': 'Contactez-nous',
    'hero.expertise': 'Nos expertises',
    'hero.partners': 'Nous travaillons avec les meilleurs fabricants',
    
    // FAQ Section
    'faq.title': 'Questions fréquemment posées',
    'faq.q1': 'Quels sont les services d\'automatisme proposés par JC Automation?',
    'faq.a1': 'JC Automation propose une large gamme de services d\'automatisme industriel, comprenant la conception et l\'implémentation de systèmes de contrôle, la programmation PLC, SCADA, HMI, l\'intégration de robots, et des solutions d\'automatisation sur mesure pour différents secteurs industriels.',
    'faq.q2': 'Comment JC Automation peut-il améliorer l\'efficacité de ma ligne de production?',
    'faq.a2': 'Notre équipe analyse votre processus de production existant pour identifier les opportunités d\'optimisation. Nous concevons et mettons en œuvre des solutions d\'automatisation personnalisées qui réduisent les temps d\'arrêt, améliorent la qualité des produits, augmentent la vitesse de production et réduisent les coûts opérationnels.',
    'faq.q3': 'Quels sont les délais typiques pour un projet d\'automatisation?',
    'faq.a3': 'Les délais varient en fonction de la complexité et de l\'ampleur du projet. Un projet simple peut prendre quelques semaines, tandis que des projets d\'automatisation complexes peuvent s\'étendre sur plusieurs mois. Nous établissons toujours un calendrier détaillé et transparent lors de la phase initiale du projet.',
    'faq.q4': 'Proposez-vous des services de maintenance pour les systèmes automatisés?',
    'faq.a4': 'Oui, JC Automation offre des contrats de maintenance préventive et corrective pour garantir le fonctionnement optimal de vos systèmes d\'automatisation. Nous proposons également une assistance à distance, des interventions d\'urgence et des formations pour votre personnel technique.',
    'faq.q5': 'Avec quels secteurs industriels travaillez-vous principalement?',
    'faq.a5': 'Nous travaillons avec une variété de secteurs industriels, notamment l\'agroalimentaire, la chimie, la pharmacie, l\'automobile, l\'exploitation minière, le traitement de l\'eau, et bien d\'autres. Notre expertise est adaptable à presque tous les environnements industriels nécessitant des solutions d\'automatisation.',
    'faq.q6': 'Comment démarrer un projet avec JC Automation?',
    'faq.a6': 'Pour démarrer un projet, contactez-nous via le formulaire sur notre site web, par téléphone ou par email. Nous organiserons une consultation initiale pour comprendre vos besoins, puis nous vous proposerons une solution adaptée accompagnée d\'un devis détaillé.',
    
    // Career Page
    'career.title': 'Rejoignez notre équipe',
    'career.subtitle': 'Découvrez les opportunités de carrière chez JC Automation',
    'career.join-us': 'Pourquoi nous rejoindre?',
    'career.apply': 'Postuler',
    'career.no-positions': 'Aucun poste ouvert actuellement. Merci de vérifier ultérieurement.',
    
    // Application Page
    'apply.back': 'Retour aux carrières',
    'apply.for': 'Postuler pour',
    'apply.form': 'Veuillez remplir le formulaire ci-dessous pour soumettre votre candidature.',
    'apply.firstName': 'Prénom',
    'apply.lastName': 'Nom',
    'apply.email': 'Email',
    'apply.phone': 'Téléphone',
    'apply.linkedin': 'LinkedIn (optionnel)',
    'apply.linkedin.help': 'Partagez votre profil LinkedIn pour nous aider à mieux vous connaître.',
    'apply.cv': 'CV (PDF, max 5MB)',
    'apply.cv.upload': 'Cliquez pour télécharger votre CV',
    'apply.cv.required': 'Veuillez télécharger votre CV.',
    'apply.coverLetter': 'Lettre de motivation',
    'apply.coverLetter.placeholder': 'Parlez-nous un peu de vous et pourquoi vous êtes intéressé par ce poste...',
    'apply.submit': 'Soumettre la candidature',
    'apply.success.title': 'Candidature envoyée',
    'apply.success.message': 'Nous avons bien reçu votre candidature et vous contacterons prochainement.',
    'apply.error.title': 'Erreur',
    
    // Legal Pages
    'legal.lastUpdated': 'Dernière mise à jour',
    'legal.contactUs': 'Contactez-nous',
    'legal.phone': 'Téléphone',
  },
  en: {
    // Navbar
    'nav.expertise': 'Expertise',
    'nav.energy-solutions': 'Energy Solutions',
    'nav.about': 'About Us',
    'nav.references': 'References',
    'nav.blog': 'Blog',
    'nav.contact': 'Contact',
    'nav.contact-us': 'Contact Us',
    'nav.career': 'Careers',
    
    // Hero Section
    'hero.title': 'Industrial Automation and Custom Solutions',
    'hero.subtitle': 'Reliable partner for all industries. Integrator of custom solutions in electricity and automation.',
    'hero.cta': 'Contact Us',
    'hero.expertise': 'Our Expertise',
    'hero.partners': 'We work with the best manufacturers',
    
    // FAQ Section
    'faq.title': 'Frequently Asked Questions',
    'faq.q1': 'What automation services does JC Automation offer?',
    'faq.a1': 'JC Automation offers a wide range of industrial automation services, including design and implementation of control systems, PLC programming, SCADA, HMI, robot integration, and custom automation solutions for various industrial sectors.',
    'faq.q2': 'How can JC Automation improve the efficiency of my production line?',
    'faq.a2': 'Our team analyzes your existing production process to identify optimization opportunities. We design and implement customized automation solutions that reduce downtime, improve product quality, increase production speed, and lower operational costs.',
    'faq.q3': 'What are the typical timelines for an automation project?',
    'faq.a3': 'Timelines vary depending on the complexity and scope of the project. A simple project may take a few weeks, while complex automation projects may extend over several months. We always establish a detailed and transparent schedule during the initial project phase.',
    'faq.q4': 'Do you offer maintenance services for automated systems?',
    'faq.a4': 'Yes, JC Automation offers preventive and corrective maintenance contracts to ensure optimal functioning of your automation systems. We also provide remote assistance, emergency interventions, and training for your technical staff.',
    'faq.q5': 'Which industrial sectors do you primarily work with?',
    'faq.a5': 'We work with a variety of industrial sectors, including food processing, chemicals, pharmaceuticals, automotive, mining, water treatment, and many others. Our expertise is adaptable to almost any industrial environment requiring automation solutions.',
    'faq.q6': 'How do I start a project with JC Automation?',
    'faq.a6': 'To start a project, contact us via the form on our website, by phone, or by email. We will arrange an initial consultation to understand your needs, then we will propose a suitable solution accompanied by a detailed quote.',
    
    // Career Page
    'career.title': 'Join Our Team',
    'career.subtitle': 'Discover career opportunities at JC Automation',
    'career.join-us': 'Why Join Us?',
    'career.apply': 'Apply',
    'career.no-positions': 'No open positions currently. Please check back later.',
    
    // Application Page
    'apply.back': 'Back to careers',
    'apply.for': 'Apply for',
    'apply.form': 'Please fill out the form below to submit your application.',
    'apply.firstName': 'First Name',
    'apply.lastName': 'Last Name',
    'apply.email': 'Email',
    'apply.phone': 'Phone',
    'apply.linkedin': 'LinkedIn (optional)',
    'apply.linkedin.help': 'Share your LinkedIn profile to help us know you better.',
    'apply.cv': 'CV (PDF, max 5MB)',
    'apply.cv.upload': 'Click to upload your CV',
    'apply.cv.required': 'Please upload your CV.',
    'apply.coverLetter': 'Cover Letter',
    'apply.coverLetter.placeholder': 'Tell us a bit about yourself and why you are interested in this position...',
    'apply.submit': 'Submit Application',
    'apply.success.title': 'Application Submitted',
    'apply.success.message': 'We have received your application and will contact you soon.',
    'apply.error.title': 'Error',
    
    // Legal Pages
    'legal.lastUpdated': 'Last updated',
    'legal.contactUs': 'Contact Us',
    'legal.phone': 'Phone',
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Try to get the language from localStorage, default to French
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('language');
    return (savedLanguage === 'en' ? 'en' : 'fr') as Language;
  });

  // Update localStorage when language changes
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    localStorage.setItem('language', newLanguage);
  };

  // Translation function
  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
