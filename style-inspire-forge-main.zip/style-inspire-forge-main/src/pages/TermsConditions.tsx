
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Separator } from '@/components/ui/separator';
import { useLanguage } from '@/contexts/LanguageContext';

const TermsConditions = () => {
  const { language } = useLanguage();
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <h1 className="text-3xl md:text-4xl font-bold text-jcdarkgray mb-6">
            {language === 'fr' ? 'Conditions générales d\'utilisation' : 'Terms & Conditions'}
          </h1>
          <Separator className="mb-8" />
          
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-600 mb-6">
              {language === 'fr' 
                ? 'Dernière mise à jour : 9 mai 2025'
                : 'Last updated: May 9, 2025'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '1. Acceptation des conditions' : '1. Acceptance of Terms'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'En accédant et en utilisant le site web de JC Automation, vous acceptez d\'être lié par ces conditions d\'utilisation, toutes les lois et réglementations applicables, et vous acceptez que vous êtes responsable du respect des lois locales applicables. Si vous n\'êtes pas d\'accord avec l\'une de ces conditions, vous êtes interdit d\'utiliser ou d\'accéder à ce site.'
                : 'By accessing and using the JC Automation website, you agree to be bound by these terms of use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '2. Utilisation de la licence' : '2. License Usage'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'La permission est accordée pour télécharger temporairement une copie des documents sur le site web de JC Automation pour un usage personnel, non commercial transitoire. Il s\'agit de l\'octroi d\'une licence, et non d\'un transfert de titre, et sous cette licence, vous ne pouvez pas:'
                : 'Permission is granted to temporarily download one copy of the materials on JC Automation\'s website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:'}
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-6">
              <li>
                {language === 'fr'
                  ? 'Modifier ou copier les matériaux;'
                  : 'Modify or copy the materials;'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Utiliser les matériaux à des fins commerciales ou pour toute présentation publique;'
                  : 'Use the materials for any commercial purpose or for any public display;'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Tenter de décompiler ou de désosser tout logiciel contenu sur le site web de JC Automation;'
                  : 'Attempt to decompile or reverse engineer any software contained on JC Automation\'s website;'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Supprimer tout droit d\'auteur ou autres notations de propriété des matériaux; ou'
                  : 'Remove any copyright or other proprietary notations from the materials; or'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Transférer les matériaux à une autre personne ou "mettre en miroir" les matériaux sur un autre serveur.'
                  : 'Transfer the materials to another person or "mirror" the materials on any other server.'}
              </li>
            </ul>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '3. Clause de non-responsabilité' : '3. Disclaimer'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Les matériaux sur le site web de JC Automation sont fournis "tels quels". JC Automation ne donne aucune garantie, expresse ou implicite, et décline et annule par la présente toutes les autres garanties, y compris, sans limitation, les garanties ou conditions implicites de qualité marchande, d\'adéquation à un usage particulier, ou de non-violation de la propriété intellectuelle ou autre violation des droits.'
                : 'The materials on JC Automation\'s website are provided "as is". JC Automation makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties, including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '4. Limitations' : '4. Limitations'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'En aucun cas, JC Automation ou ses fournisseurs ne seront responsables de tout dommage (y compris, sans limitation, les dommages pour perte de données ou de profit, ou en raison d\'une interruption d\'activité) découlant de l\'utilisation ou de l\'impossibilité d\'utiliser les matériaux sur le site web de JC Automation, même si JC Automation ou un représentant autorisé de JC Automation a été notifié oralement ou par écrit de la possibilité de tels dommages.'
                : 'In no event shall JC Automation or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on JC Automation\'s website, even if JC Automation or a JC Automation authorized representative has been notified orally or in writing of the possibility of such damage.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '5. Révisions et errata' : '5. Revisions and Errata'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Les matériaux apparaissant sur le site web de JC Automation peuvent inclure des erreurs techniques, typographiques ou photographiques. JC Automation ne garantit pas que les matériaux de ce site web sont exacts, complets ou à jour. JC Automation peut apporter des modifications aux matériaux contenus sur son site web à tout moment sans préavis.'
                : 'The materials appearing on JC Automation\'s website could include technical, typographical, or photographic errors. JC Automation does not warrant that any of the materials on its website are accurate, complete, or current. JC Automation may make changes to the materials contained on its website at any time without notice.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '6. Liens' : '6. Links'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'JC Automation n\'a pas examiné tous les sites liés à son site web et n\'est pas responsable du contenu de ces sites liés. L\'inclusion de tout lien n\'implique pas l\'approbation par JC Automation du site. L\'utilisation de tout site web lié est aux risques et périls de l\'utilisateur.'
                : 'JC Automation has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by JC Automation of the site. Use of any such linked website is at the user\'s own risk.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '7. Droit applicable' : '7. Applicable Law'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Ces conditions d\'utilisation sont régies par et interprétées conformément aux lois du Maroc, et vous vous soumettez irrévocablement à la juridiction exclusive des tribunaux de ce pays.'
                : 'These terms of use are governed by and construed in accordance with the laws of Morocco, and you irrevocably submit to the exclusive jurisdiction of the courts in that country.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? '8. Contact' : '8. Contact'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Pour toute question concernant ces conditions d\'utilisation, veuillez nous contacter à:'
                : 'If you have any questions regarding these terms of use, please contact us at:'}
            </p>
            <p className="text-gray-600 mb-4">
              JC Automation<br />
              {language === 'fr'
                ? '61, Avenue Lalla Yacout, Angle Mustapha El Maani - Casablanca'
                : '61, Avenue Lalla Yacout, Corner of Mustapha El Maani - Casablanca'}<br />
              Email: jcautomationmaroc@gmail.com<br />
              {language === 'fr' ? 'Téléphone: +212 522 74 23 40' : 'Phone: +212 522 74 23 40'}
            </p>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default TermsConditions;
