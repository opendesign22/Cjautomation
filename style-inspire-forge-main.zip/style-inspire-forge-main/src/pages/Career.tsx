import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Briefcase, BuildingIcon, GraduationCap, Users } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';

const Career = () => {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  
  // Career opportunities data
  const opportunities = [
    {
      id: 1,
      title: language === 'fr' ? 'Ingénieur Automaticien' : 'Automation Engineer',
      type: language === 'fr' ? 'Temps plein' : 'Full Time',
      location: language === 'fr' ? 'Casablanca, Maroc' : 'Casablanca, Morocco',
      description: language === 'fr' 
        ? "Nous recherchons un ingénieur automaticien expérimenté pour rejoindre notre équipe. Vous serez responsable de la conception et de l'implémentation de solutions d'automatisation pour nos clients industriels."
        : "We're looking for an experienced automation engineer to join our team. You'll be responsible for designing and implementing automation solutions for our industrial clients."
    },
    {
      id: 2,
      title: language === 'fr' ? 'Technicien en Électricité Industrielle' : 'Industrial Electrical Technician',
      type: language === 'fr' ? 'Temps plein' : 'Full Time',
      location: language === 'fr' ? 'Casablanca, Maroc' : 'Casablanca, Morocco',
      description: language === 'fr' 
        ? "Rejoignez notre équipe en tant que technicien en électricité industrielle. Vous serez en charge de l'installation et de la maintenance des systèmes électriques dans des environnements industriels."
        : "Join our team as an industrial electrical technician. You'll be responsible for installing and maintaining electrical systems in industrial environments."
    },
    {
      id: 3,
      title: language === 'fr' ? 'Ingénieur en Solutions Énergétiques' : 'Energy Solutions Engineer',
      type: language === 'fr' ? 'Temps plein' : 'Full Time',
      location: language === 'fr' ? 'Casablanca, Maroc' : 'Casablanca, Morocco',
      description: language === 'fr' 
        ? "Nous recherchons un ingénieur spécialisé dans les solutions énergétiques pour développer et implémenter des projets d'efficacité énergétique pour nos clients."
        : "We're looking for an engineer specialized in energy solutions to develop and implement energy efficiency projects for our clients."
    }
  ];
  
  const handleApply = (jobTitle: string) => {
    navigate(`/apply?title=${encodeURIComponent(jobTitle)}`);
  };
  
  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Navbar />
      
      <main className="flex-grow mt-20">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-gray-100 to-gray-200 py-20">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl font-bold tracking-tight text-jcdarkgray sm:text-5xl mb-6">
                {language === 'fr' ? 'Rejoignez Notre Équipe' : 'Join Our Team'}
              </h1>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                {language === 'fr' 
                  ? "Découvrez les opportunités de carrière chez JC Automation et participez à des projets innovants dans le domaine de l'automatisation et de l'électricité industrielle."
                  : "Discover career opportunities at JC Automation and be part of innovative projects in the field of automation and industrial electricity."}
              </p>
            </div>
          </div>
        </section>

        {/* Why Join Us Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl font-bold text-center text-jcdarkgray mb-12">
              {language === 'fr' ? 'Pourquoi Nous Rejoindre' : 'Why Join Us'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-jcred/10 p-3 rounded-full">
                    <GraduationCap className="h-8 w-8 text-jcred" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-jcdarkgray">
                  {language === 'fr' ? 'Développement Professionnel' : 'Professional Development'}
                </h3>
                <p className="text-gray-600">
                  {language === 'fr' 
                    ? "Nous investissons dans votre croissance avec des formations continues et des opportunités d'avancement."
                    : "We invest in your growth with continuous training and advancement opportunities."}
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-jcred/10 p-3 rounded-full">
                    <Users className="h-8 w-8 text-jcred" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-jcdarkgray">
                  {language === 'fr' ? 'Équipe Dynamique' : 'Dynamic Team'}
                </h3>
                <p className="text-gray-600">
                  {language === 'fr' 
                    ? "Rejoignez une équipe passionnée et collaborative qui valorise l'innovation et le travail d'équipe."
                    : "Join a passionate and collaborative team that values innovation and teamwork."}
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 text-center">
                <div className="flex justify-center mb-4">
                  <div className="bg-jcred/10 p-3 rounded-full">
                    <BuildingIcon className="h-8 w-8 text-jcred" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-jcdarkgray">
                  {language === 'fr' ? 'Projets Innovants' : 'Innovative Projects'}
                </h3>
                <p className="text-gray-600">
                  {language === 'fr' 
                    ? "Travaillez sur des projets variés et stimulants avec les dernières technologies du secteur."
                    : "Work on diverse and challenging projects with the latest industry technologies."}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Current Openings Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl font-bold text-center text-jcdarkgray mb-12">
              {language === 'fr' ? 'Offres d\'Emploi Actuelles' : 'Current Openings'}
            </h2>
            
            <div className="space-y-6 max-w-4xl mx-auto">
              {opportunities.map((job) => (
                <Card key={job.id} className="overflow-hidden border-gray-200 hover:border-jcred transition-colors duration-300">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Briefcase className="h-5 w-5 text-jcred" />
                          <span className="text-sm font-medium text-gray-500">{job.type}</span>
                          <span className="text-gray-400">•</span>
                          <span className="text-sm text-gray-500">{job.location}</span>
                        </div>
                        <h3 className="text-xl font-semibold mb-2 text-jcdarkgray">{job.title}</h3>
                        <p className="text-gray-600 mb-4">{job.description}</p>
                      </div>
                      
                      <Button 
                        className="whitespace-nowrap bg-jcred hover:bg-red-700 text-white self-start md:self-center"
                        onClick={() => handleApply(job.title)}
                      >
                        {language === 'fr' ? 'Postuler' : 'Apply'} <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Application Process Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl font-bold text-center text-jcdarkgray mb-12">
              {language === 'fr' ? 'Processus de Recrutement' : 'Application Process'}
            </h2>
            
            <div className="max-w-3xl mx-auto">
              <div className="relative">
                {/* Timeline Line */}
                <div className="absolute left-8 top-0 bottom-0 w-1 bg-gray-200 md:left-1/2 md:-ml-0.5"></div>
                
                {/* Timeline Items */}
                <div className="space-y-12">
                  {/* Step 1 */}
                  <div className="relative flex items-start md:justify-between">
                    <div className="flex flex-col items-center md:w-5/12">
                      <div className="bg-jcred text-white w-16 h-16 rounded-full flex items-center justify-center z-10 text-xl font-semibold">1</div>
                      <div className="mt-4 md:mt-6 bg-white p-6 rounded-lg shadow-md border border-gray-100 w-full">
                        <h3 className="text-lg font-semibold mb-2 text-jcdarkgray">
                          {language === 'fr' ? 'Candidature en Ligne' : 'Online Application'}
                        </h3>
                        <p className="text-gray-600">
                          {language === 'fr' 
                            ? "Soumettez votre CV et une lettre de motivation via notre formulaire en ligne."
                            : "Submit your resume and cover letter through our online form."}
                        </p>
                      </div>
                    </div>
                    <div className="hidden md:block md:w-5/12"></div>
                  </div>
                  
                  {/* Step 2 */}
                  <div className="relative flex items-start md:justify-between">
                    <div className="hidden md:block md:w-5/12"></div>
                    <div className="flex flex-col items-center md:w-5/12">
                      <div className="bg-jcred text-white w-16 h-16 rounded-full flex items-center justify-center z-10 text-xl font-semibold">2</div>
                      <div className="mt-4 md:mt-6 bg-white p-6 rounded-lg shadow-md border border-gray-100 w-full">
                        <h3 className="text-lg font-semibold mb-2 text-jcdarkgray">
                          {language === 'fr' ? 'Entretien Initial' : 'Initial Interview'}
                        </h3>
                        <p className="text-gray-600">
                          {language === 'fr' 
                            ? "Un entretien téléphonique ou vidéo pour discuter de votre expérience et de vos compétences."
                            : "A phone or video interview to discuss your experience and skills."}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Step 3 */}
                  <div className="relative flex items-start md:justify-between">
                    <div className="flex flex-col items-center md:w-5/12">
                      <div className="bg-jcred text-white w-16 h-16 rounded-full flex items-center justify-center z-10 text-xl font-semibold">3</div>
                      <div className="mt-4 md:mt-6 bg-white p-6 rounded-lg shadow-md border border-gray-100 w-full">
                        <h3 className="text-lg font-semibold mb-2 text-jcdarkgray">
                          {language === 'fr' ? 'Entretien Technique' : 'Technical Interview'}
                        </h3>
                        <p className="text-gray-600">
                          {language === 'fr' 
                            ? "Évaluation de vos connaissances techniques par nos experts."
                            : "Assessment of your technical knowledge by our experts."}
                        </p>
                      </div>
                    </div>
                    <div className="hidden md:block md:w-5/12"></div>
                  </div>
                  
                  {/* Step 4 */}
                  <div className="relative flex items-start md:justify-between">
                    <div className="hidden md:block md:w-5/12"></div>
                    <div className="flex flex-col items-center md:w-5/12">
                      <div className="bg-jcred text-white w-16 h-16 rounded-full flex items-center justify-center z-10 text-xl font-semibold">4</div>
                      <div className="mt-4 md:mt-6 bg-white p-6 rounded-lg shadow-md border border-gray-100 w-full">
                        <h3 className="text-lg font-semibold mb-2 text-jcdarkgray">
                          {language === 'fr' ? 'Offre d\'Emploi' : 'Job Offer'}
                        </h3>
                        <p className="text-gray-600">
                          {language === 'fr' 
                            ? "Si votre profil correspond, nous vous ferons une proposition adaptée à vos compétences."
                            : "If your profile matches, we'll make you an offer tailored to your skills."}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Contact CTA Section */}
        <section className="bg-gradient-to-r from-jcdarkgray to-gray-800 text-white py-16">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <h2 className="text-3xl font-bold mb-6">
              {language === 'fr' ? 'Vous ne trouvez pas le poste qui vous convient ?' : 'Don\'t see the right position for you?'}
            </h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              {language === 'fr' 
                ? "Envoyez-nous votre CV et nous vous contacterons si un poste correspondant à votre profil se libère."
                : "Send us your resume and we'll reach out if a position matching your profile becomes available."}
            </p>
            <Button 
              className="bg-jcred hover:bg-red-700 text-white px-8 py-2 text-lg"
              onClick={() => navigate('/apply')}
            >
              {language === 'fr' ? 'Envoyez Votre CV' : 'Send Your Resume'} <ArrowRight className="ml-1 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Career;
