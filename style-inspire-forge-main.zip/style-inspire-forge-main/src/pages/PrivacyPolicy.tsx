
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Separator } from '@/components/ui/separator';
import { useLanguage } from '@/contexts/LanguageContext';

const PrivacyPolicy = () => {
  const { language } = useLanguage();
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <h1 className="text-3xl md:text-4xl font-bold text-jcdarkgray mb-6">
            {language === 'fr' ? 'Politique de confidentialité' : 'Privacy Policy'}
          </h1>
          <Separator className="mb-8" />
          
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-600 mb-6">
              {language === 'fr' 
                ? 'Dernière mise à jour : 9 mai 2025'
                : 'Last updated: May 9, 2025'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Introduction' : 'Introduction'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'JC Automation ("nous", "notre", "nos") s\'engage à protéger la vie privée et les informations personnelles des utilisateurs de notre site web. Cette politique de confidentialité décrit comment nous collectons, utilisons et protégeons vos informations lorsque vous visitez notre site web et utilisez nos services.'
                : 'JC Automation ("we", "our", "us") is committed to protecting the privacy and personal information of users of our website. This privacy policy describes how we collect, use, and protect your information when you visit our website and use our services.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Collecte d\'informations' : 'Information Collection'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Nous collectons les informations personnelles que vous nous fournissez volontairement lorsque vous utilisez notre site web, comme lorsque vous remplissez des formulaires, vous inscrivez à notre newsletter, ou nous contactez. Ces informations peuvent inclure votre nom, adresse e-mail, numéro de téléphone, et le contenu de vos messages.'
                : 'We collect personal information that you voluntarily provide when using our website, such as when you fill out forms, subscribe to our newsletter, or contact us. This information may include your name, email address, phone number, and the content of your messages.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Utilisation des informations' : 'Use of Information'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Nous utilisons les informations personnelles que nous collectons pour:'
                : 'We use the personal information we collect to:'}
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-6">
              <li>
                {language === 'fr'
                  ? 'Répondre à vos demandes et fournir les services que vous avez demandés'
                  : 'Respond to your requests and provide the services you have requested'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Vous envoyer des communications marketing si vous avez opté pour les recevoir'
                  : 'Send you marketing communications if you have opted to receive them'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Améliorer notre site web et nos services'
                  : 'Improve our website and services'}
              </li>
              <li>
                {language === 'fr'
                  ? 'Se conformer à nos obligations légales'
                  : 'Comply with our legal obligations'}
              </li>
            </ul>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Partage des informations' : 'Information Sharing'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Nous ne vendons, n\'échangeons ou ne transférons pas vos informations personnelles à des tiers sans votre consentement, sauf lorsque cela est nécessaire pour fournir un service que vous avez demandé ou lorsque la loi nous y oblige.'
                : 'We do not sell, trade, or transfer your personal information to third parties without your consent, except when necessary to provide a service you have requested or when required by law.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Sécurité' : 'Security'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Nous mettons en œuvre des mesures de sécurité appropriées pour protéger vos informations personnelles contre l\'accès non autorisé, l\'altération, la divulgation ou la destruction.'
                : 'We implement appropriate security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Cookies' : 'Cookies'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Notre site web peut utiliser des "cookies" pour améliorer votre expérience. Vous pouvez configurer votre navigateur pour refuser tous les cookies ou pour vous avertir lorsque des cookies sont envoyés.'
                : 'Our website may use "cookies" to improve your experience. You can configure your browser to refuse all cookies or to alert you when cookies are being sent.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Vos droits' : 'Your Rights'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Vous avez le droit d\'accéder, de corriger, de mettre à jour ou de supprimer vos informations personnelles. Si vous souhaitez exercer ces droits, veuillez nous contacter aux coordonnées fournies ci-dessous.'
                : 'You have the right to access, correct, update, or delete your personal information. If you wish to exercise these rights, please contact us using the contact information provided below.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Modifications de cette politique' : 'Policy Changes'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Nous pouvons mettre à jour cette politique de confidentialité de temps à autre. La date de la dernière révision sera indiquée en haut de la page.'
                : 'We may update this privacy policy from time to time. The date of the last revision will be indicated at the top of the page.'}
            </p>
            
            <h2 className="text-2xl font-semibold text-jcdarkgray mt-8 mb-4">
              {language === 'fr' ? 'Contactez-nous' : 'Contact Us'}
            </h2>
            <p className="text-gray-600 mb-4">
              {language === 'fr'
                ? 'Si vous avez des questions concernant cette politique de confidentialité, veuillez nous contacter à:'
                : 'If you have any questions regarding this privacy policy, please contact us at:'}
            </p>
            <p className="text-gray-600 mb-4">
              JC Automation<br />
              {language === 'fr'
                ? '61, Avenue Lalla Yacout, Angle Mustapha El Maani - Casablanca'
                : '61, Avenue Lalla Yacout, Corner of Mustapha El Maani - Casablanca'}<br />
              Email: jcautomationmaroc@gmail.com<br />
              {language === 'fr' ? 'Téléphone: +212 522 74 23 40' : 'Phone: +212 522 74 23 40'}
            </p>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default PrivacyPolicy;
