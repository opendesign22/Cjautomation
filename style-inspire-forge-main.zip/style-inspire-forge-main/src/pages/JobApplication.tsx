
import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { ArrowLeft, Upload } from 'lucide-react';
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Label } from '@/components/ui/label';

const JobApplication = () => {
  const { language, t } = useLanguage();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const jobTitle = searchParams.get('title') || '';
  
  // Form schema with validation
  const formSchema = z.object({
    firstName: z.string().min(2, {
      message: language === 'fr' 
        ? "Le prénom doit contenir au moins 2 caractères." 
        : "First name must be at least 2 characters.",
    }),
    lastName: z.string().min(2, {
      message: language === 'fr' 
        ? "Le nom doit contenir au moins 2 caractères." 
        : "Last name must be at least 2 characters.",
    }),
    email: z.string().email({
      message: language === 'fr' 
        ? "Adresse e-mail invalide." 
        : "Invalid email address.",
    }),
    phone: z.string().min(10, {
      message: language === 'fr' 
        ? "Le numéro de téléphone doit contenir au moins 10 chiffres." 
        : "Phone number must be at least 10 digits.",
    }),
    linkedin: z.string().optional(),
    coverLetter: z.string().min(50, {
      message: language === 'fr' 
        ? "La lettre de motivation doit contenir au moins 50 caractères." 
        : "Cover letter must be at least 50 characters.",
    }),
  });
  
  // Form definition
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      linkedin: "",
      coverLetter: "",
    },
  });
  
  // File upload state
  const [cvFile, setCvFile] = React.useState<File | null>(null);
  
  // Handle file change
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCvFile(file);
    }
  };
  
  // Form submission
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (!cvFile) {
      toast({
        title: t('apply.error.title'),
        description: t('apply.cv.required'),
        variant: "destructive",
      });
      return;
    }
    
    console.log("Form submitted:", values);
    console.log("CV File:", cvFile);
    
    // Show success toast
    toast({
      title: t('apply.success.title'),
      description: t('apply.success.message'),
    });
    
    // Redirect back to careers page after submission
    setTimeout(() => {
      navigate('/career');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/career')}
            className="mb-6 text-jcdarkgray hover:text-jcred"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            {t('apply.back')}
          </Button>
          
          <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl font-bold tracking-tight text-jcdarkgray mb-2">
              {t('apply.for')}: {jobTitle}
            </h1>
            <p className="text-gray-500 mb-8">
              {t('apply.form')}
            </p>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('apply.firstName')}</FormLabel>
                        <FormControl>
                          <Input placeholder={t('apply.firstName')} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('apply.lastName')}</FormLabel>
                        <FormControl>
                          <Input placeholder={t('apply.lastName')} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('apply.email')}</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="email@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('apply.phone')}</FormLabel>
                        <FormControl>
                          <Input placeholder="+212 XXXXXXXXX" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="linkedin"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('apply.linkedin')}</FormLabel>
                      <FormControl>
                        <Input placeholder="https://linkedin.com/in/yourprofile" {...field} />
                      </FormControl>
                      <FormDescription>
                        {t('apply.linkedin.help')}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div>
                  <Label htmlFor="cv-upload">
                    {t('apply.cv')}
                  </Label>
                  <div className="mt-2">
                    <div className="flex items-center justify-center w-full">
                      <label 
                        htmlFor="cv-upload" 
                        className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
                      >
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Upload className="w-8 h-8 mb-3 text-gray-400" />
                          <p className="mb-2 text-sm text-gray-500">
                            {cvFile 
                              ? cvFile.name
                              : t('apply.cv.upload')
                            }
                          </p>
                          <p className="text-xs text-gray-500">
                            {t('apply.cv')}
                          </p>
                        </div>
                        <Input 
                          id="cv-upload" 
                          type="file" 
                          accept=".pdf" 
                          className="hidden" 
                          onChange={handleFileChange}
                          required
                        />
                      </label>
                    </div>
                  </div>
                  {!cvFile && form.formState.isSubmitted && (
                    <p className="text-sm font-medium text-destructive mt-2">
                      {t('apply.cv.required')}
                    </p>
                  )}
                </div>
                
                <FormField
                  control={form.control}
                  name="coverLetter"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('apply.coverLetter')}</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder={t('apply.coverLetter.placeholder')} 
                          className="min-h-32" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end pt-4">
                  <Button type="submit" className="bg-jcred hover:bg-red-700 text-white px-8">
                    {t('apply.submit')}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default JobApplication;
