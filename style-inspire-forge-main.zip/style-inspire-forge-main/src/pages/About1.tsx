
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Separator } from '@/components/ui/separator';
import { useLanguage } from '@/contexts/LanguageContext';

const About = () => {
  const { language } = useLanguage();
  
  // Team members data
  const teamMembers = [
    {
      name: "Jean-Claude Dupont",
      position: language === 'fr' ? "Fondateur & Directeur Général" : "Founder & CEO",
      bio: language === 'fr' 
        ? "Avec plus de 25 ans d'expérience dans l'automatisme industriel, Jean-Claude a fondé JC Automation avec la vision de fournir des solutions d'automatisation innovantes et sur mesure pour répondre aux défis industriels modernes."
        : "With over 25 years of experience in industrial automation, Jean-Claude founded JC Automation with the vision of providing innovative and customized automation solutions to address modern industrial challenges.",
      image: ""
    },
    {
      name: "Sophie Benali",
      position: language === 'fr' ? "Directrice Technique" : "Technical Director",
      bio: language === 'fr'
        ? "Ingénieure en électronique et automatisme, Sophie supervise tous les aspects techniques des projets, assurant des solutions de haute qualité qui répondent aux spécifications des clients."
        : "An electronics and automation engineer, Sophie oversees all technical aspects of projects, ensuring high-quality solutions that meet client specifications.",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Ahmed Lahrichi",
      position: language === 'fr' ? "Chef de Projet" : "Project Manager",
      bio: language === 'fr'
        ? "Fort d'une expérience de 15 ans dans la gestion de projets industriels, Ahmed assure la livraison en temps voulu et dans le respect du budget de tous les projets d'automatisation."
        : "With 15 years of experience in industrial project management, Ahmed ensures the timely and on-budget delivery of all automation projects.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80"
    }
  ];

  // Milestones data
  const milestones = [
    {
      year: "2005",
      title: language === 'fr' ? "Fondation de l'entreprise" : "Company Foundation",
      description: language === 'fr'
        ? "JC Automation est fondée à Casablanca avec une équipe de 3 personnes, se spécialisant dans l'automatisation des processus industriels."
        : "JC Automation is founded in Casablanca with a team of 3 people, specializing in industrial process automation."
    },
    {
      year: "2010",
      title: language === 'fr' ? "Expansion régionale" : "Regional Expansion",
      description: language === 'fr'
        ? "Ouverture de bureaux à Rabat et Tanger pour mieux servir les clients dans tout le Maroc."
        : "Opening of offices in Rabat and Tangier to better serve clients throughout Morocco."
    },
    {
      year: "2015",
      title: language === 'fr' ? "Partenariats stratégiques" : "Strategic Partnerships",
      description: language === 'fr'
        ? "Établissement de partenariats officiels avec Siemens, Schneider Electric et d'autres leaders du secteur."
        : "Establishment of official partnerships with Siemens, Schneider Electric and other industry leaders."
    },
    {
      year: "2018",
      title: language === 'fr' ? "Innovation en énergies renouvelables" : "Renewable Energy Innovation",
      description: language === 'fr'
        ? "Lancement de la division dédiée aux solutions d'automatisation pour les installations d'énergie renouvelable."
        : "Launch of the division dedicated to automation solutions for renewable energy installations."
    },
    {
      year: "2022",
      title: language === 'fr' ? "Excellence reconnue" : "Recognized Excellence",
      description: language === 'fr'
        ? "Réception du prix de l'innovation industrielle pour nos solutions d'automatisation dans le secteur agroalimentaire."
        : "Received the industrial innovation award for our automation solutions in the food processing sector."
    },
    {
      year: "2024",
      title: language === 'fr' ? "Expansion internationale" : "International Expansion",
      description: language === 'fr'
        ? "Début des opérations en Afrique de l'Ouest avec des projets au Sénégal et en Côte d'Ivoire."
        : "Start of operations in West Africa with projects in Senegal and Ivory Coast."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold text-jcdarkgray mb-6">
              {language === 'fr' ? 'À propos de JC Automation' : 'About JC Automation'}
            </h1>
            <Separator className="mb-8" />
            
            {/* Company Overview */}
            <div className="mb-16">
              <h2 className="text-2xl font-semibold text-jcdarkgray mb-4">
                {language === 'fr' ? 'Notre Mission' : 'Our Mission'}
              </h2>
              <p className="text-gray-600 mb-6">
                {language === 'fr'
                  ? "JC Automation a pour mission de transformer les environnements industriels grâce à des solutions d'automatisation innovantes et sur mesure, permettant à nos clients d'améliorer leur efficacité opérationnelle, de réduire leurs coûts et d'accroître leur compétitivité dans un monde en constante évolution."
                  : "JC Automation's mission is to transform industrial environments through innovative and customized automation solutions, enabling our clients to improve their operational efficiency, reduce costs, and increase their competitiveness in an ever-changing world."}
              </p>
              
              <h2 className="text-2xl font-semibold text-jcdarkgray mb-4">
                {language === 'fr' ? 'Notre Vision' : 'Our Vision'}
              </h2>
              <p className="text-gray-600 mb-6">
                {language === 'fr'
                  ? "Devenir le partenaire de référence en automatisation industrielle au Maroc et en Afrique, reconnu pour notre excellence technique, notre innovation constante et notre engagement envers la satisfaction totale du client."
                  : "To become the reference partner in industrial automation in Morocco and Africa, recognized for our technical excellence, constant innovation, and commitment to total customer satisfaction."}
              </p>
              
              <h2 className="text-2xl font-semibold text-jcdarkgray mb-4">
                {language === 'fr' ? 'Nos Valeurs' : 'Our Values'}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                <div className="bg-gray-50 p-6 rounded-lg border border-gray-100">
                  <h3 className="text-lg font-medium text-jcred mb-2">
                    {language === 'fr' ? 'Excellence' : 'Excellence'}
                  </h3>
                  <p className="text-gray-600">
                    {language === 'fr'
                      ? "Nous nous efforçons d'atteindre l'excellence dans tous les aspects de notre travail, en dépassant constamment les attentes."
                      : "We strive for excellence in all aspects of our work, consistently exceeding expectations."}
                  </p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg border border-gray-100">
                  <h3 className="text-lg font-medium text-jcred mb-2">
                    {language === 'fr' ? 'Innovation' : 'Innovation'}
                  </h3>
                  <p className="text-gray-600">
                    {language === 'fr'
                      ? "Nous recherchons continuellement de nouvelles technologies et approches pour résoudre les défis industriels complexes."
                      : "We continuously seek new technologies and approaches to solve complex industrial challenges."}
                  </p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg border border-gray-100">
                  <h3 className="text-lg font-medium text-jcred mb-2">
                    {language === 'fr' ? 'Intégrité' : 'Integrity'}
                  </h3>
                  <p className="text-gray-600">
                    {language === 'fr'
                      ? "Nous agissons avec honnêteté, transparence et responsabilité dans toutes nos interactions professionnelles."
                      : "We act with honesty, transparency, and responsibility in all our professional interactions."}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Team Section */}
            <div className="mb-16">
              <h2 className="text-2xl font-semibold text-jcdarkgray mb-6">
                {language === 'fr' ? 'Notre Équipe' : 'Our Team'}
              </h2>
              <p className="text-gray-600 mb-8">
                {language === 'fr'
                  ? "Notre équipe diversifiée d'ingénieurs, de techniciens et de gestionnaires de projet possède une expertise approfondie dans divers domaines de l'automatisation industrielle. Ensemble, nous travaillons à fournir des solutions personnalisées qui répondent aux besoins uniques de chaque client."
                  : "Our diverse team of engineers, technicians, and project managers has deep expertise in various fields of industrial automation. Together, we work to provide customized solutions that meet the unique needs of each client."}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {teamMembers.map((member, index) => (
                  <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md transition-transform hover:transform hover:scale-105">
                    <img 
                      src={member.image} 
                      alt={member.name} 
                      className="w-full h-64 object-cover"
                    />
                    <div className="p-6">
                      <h3 className="text-xl font-semibold text-jcdarkgray">{member.name}</h3>
                      <p className="text-jcred font-medium mb-3">{member.position}</p>
                      <p className="text-gray-600 text-sm">{member.bio}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Company History */}
            <div>
              <h2 className="text-2xl font-semibold text-jcdarkgray mb-6">
                {language === 'fr' ? 'Notre Histoire' : 'Our History'}
              </h2>
              <div className="relative pl-8 border-l border-jcred">
                {milestones.map((milestone, index) => (
                  <div key={index} className="mb-10 ml-6">
                    <div className="absolute w-4 h-4 bg-jcred rounded-full -left-[10.5px] mt-1.5"></div>
                    <div>
                      <span className="text-jcred font-bold">{milestone.year}</span>
                      <h3 className="text-lg font-medium text-jcdarkgray mb-1">{milestone.title}</h3>
                      <p className="text-gray-600">{milestone.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default About;
