
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Tag, Calendar } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';

export type BlogPost = {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
  category: string;
};

export const blogPosts: BlogPost[] = [
  {
    id: "automatisation-industrie",
    title: "L'importance de l'automatisation dans l'industrie moderne",
    excerpt: "Découvrez comment l'automatisation industrielle transforme les processus de fabrication et améliore l'efficacité opérationnelle.",
    content: `
      <p>L'automatisation industrielle représente aujourd'hui un pilier essentiel de la transformation digitale des entreprises manufacturières. Son adoption croissante s'explique par les nombreux avantages qu'elle offre en termes de productivité, de précision et de réduction des coûts opérationnels.</p>
      
      <h2>Les bénéfices de l'automatisation</h2>
      <p>La mise en place de systèmes automatisés permet d'optimiser les chaînes de production en réduisant les temps d'arrêt et en assurant une qualité constante des produits. Les entreprises qui ont investi dans l'automatisation constatent généralement une amélioration significative de leurs performances opérationnelles.</p>
      
      <h2>L'automatisation et l'industrie 4.0</h2>
      <p>L'intégration de l'automatisation dans le cadre plus large de l'industrie 4.0 ouvre de nouvelles perspectives pour les fabricants. La combinaison des capteurs IoT, de l'intelligence artificielle et des systèmes de contrôle automatisés crée un environnement industriel plus connecté et intelligent.</p>
      
      <h2>Les défis de l'implémentation</h2>
      <p>Malgré ses avantages, l'adoption de l'automatisation pose certains défis, notamment en termes d'investissement initial, de formation du personnel et d'adaptation des processus existants. Une approche progressive et bien planifiée est souvent recommandée pour surmonter ces obstacles.</p>
      
      <h2>Le futur de l'automatisation industrielle</h2>
      <p>L'évolution constante des technologies d'automatisation promet de nouvelles avancées dans les années à venir. Les systèmes robotiques collaboratifs, l'intelligence artificielle avancée et l'analytique prédictive façonneront l'usine du futur, offrant des niveaux sans précédent d'efficacité et de flexibilité.</p>
    `,
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&w=800&q=80",
    date: "15 Mai 2025",
    category: "Automatisme"
  },
  {
    id: "solutions-energetiques",
    title: "Solutions énergétiques pour un avenir durable",
    excerpt: "Explorez nos approches innovantes pour optimiser la consommation d'énergie dans les installations industrielles.",
    content: `
      <p>Dans un contexte de transition énergétique et de préoccupations environnementales croissantes, l'optimisation de la consommation d'énergie dans les environnements industriels devient une priorité stratégique pour de nombreuses entreprises.</p>
      
      <h2>Audit énergétique : première étape vers l'efficacité</h2>
      <p>Un diagnostic complet des installations permet d'identifier les sources de gaspillage énergétique et d'établir une feuille de route pour l'amélioration de l'efficacité énergétique. Cette analyse minutieuse constitue le fondement de toute stratégie d'optimisation énergétique efficace.</p>
      
      <h2>Technologies de récupération d'énergie</h2>
      <p>Les systèmes de récupération de chaleur, les échangeurs thermiques et autres dispositifs similaires permettent de capturer l'énergie qui serait autrement perdue et de la réutiliser dans différents processus industriels, améliorant ainsi l'efficacité globale des installations.</p>
      
      <h2>L'automatisation au service de l'efficacité énergétique</h2>
      <p>Les systèmes de gestion technique du bâtiment (GTB) et les automates programmables industriels peuvent être configurés pour optimiser la consommation d'énergie en fonction des besoins réels, évitant ainsi le fonctionnement inutile des équipements pendant les périodes d'inactivité.</p>
      
      <h2>Intégration des énergies renouvelables</h2>
      <p>L'incorporation de sources d'énergie renouvelable, telles que le solaire photovoltaïque ou l'éolien, dans le mix énergétique des installations industrielles offre une solution durable pour réduire l'empreinte carbone tout en diminuant la dépendance aux énergies fossiles.</p>
    `,
    image: "https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?auto=format&fit=crop&w=800&q=80",
    date: "10 Mai 2025",
    category: "Énergie"
  },
  {
    id: "securite-electrique",
    title: "Sécurité électrique: bonnes pratiques et réglementations",
    excerpt: "Guide complet sur les normes de sécurité électrique à respecter dans les environnements industriels.",
    content: `
      <p>La sécurité électrique représente un enjeu majeur dans les environnements industriels où les installations électriques sont omniprésentes et potentiellement dangereuses si elles ne sont pas correctement conçues, installées et maintenues.</p>
      
      <h2>Réglementations et normes applicables</h2>
      <p>Les installations électriques industrielles sont soumises à diverses normes et réglementations qui évoluent régulièrement. La norme NF C 15-100 pour les installations électriques à basse tension et la directive ATEX pour les atmosphères explosives font partie des référentiels essentiels à respecter.</p>
      
      <h2>Conception sécurisée des installations</h2>
      <p>Une conception rigoureuse intégrant des dispositifs de protection adaptés (disjoncteurs, fusibles, dispositifs différentiels) constitue la première ligne de défense contre les accidents électriques. La sélectivité et la coordination de ces protections sont cruciales pour assurer une sécurité optimale.</p>
      
      <h2>Maintenance préventive et vérifications périodiques</h2>
      <p>Un programme de maintenance régulier et des inspections périodiques par des organismes certifiés permettent de détecter et corriger les anomalies avant qu'elles ne provoquent des incidents. Ces contrôles sont non seulement une obligation légale mais aussi une garantie de sécurité pour le personnel et les équipements.</p>
      
      <h2>Formation et sensibilisation du personnel</h2>
      <p>Au-delà des aspects techniques, la formation des collaborateurs aux risques électriques et l'attribution d'habilitations appropriées selon la norme NF C 18-510 sont indispensables pour créer une culture de sécurité électrique au sein de l'entreprise.</p>
    `,
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
    date: "5 Mai 2025",
    category: "Électricité"
  }
];

const Blog = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <section className="pt-28 pb-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <Button variant="outline" className="mb-6" asChild>
              <Link to="/">
                <ArrowLeft className="mr-2 h-4 w-4" /> Retour à l'accueil
              </Link>
            </Button>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Notre <span className="text-jcred">Blog</span>
            </h1>
            <div className="w-24 h-1 bg-jcred mx-auto mb-6"></div>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Découvrez nos derniers articles sur l'automatisme industriel, l'efficacité énergétique,
              et les tendances technologiques du secteur.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <div 
                key={index}
                className="blog-card overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all"
              >
                <Link to={`/blog/${post.id}`}>
                  <div 
                    className="h-48 bg-cover bg-center" 
                    style={{ backgroundImage: `url("${post.image}")` }}
                  ></div>
                </Link>
                <div className="p-5">
                  <div className="flex justify-between items-center mb-3">
                    <Badge variant="outline" className="bg-gray-50 text-jcdarkgray flex items-center gap-1">
                      <Tag className="h-3 w-3" /> {post.category}
                    </Badge>
                    <span className="text-sm text-gray-500 flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> {post.date}
                    </span>
                  </div>
                  <Link to={`/blog/${post.id}`}>
                    <h3 className="font-bold text-lg mb-2 text-jcdarkgray hover:text-jcred transition-colors">{post.title}</h3>
                  </Link>
                  <p className="text-gray-600 text-sm mb-4">{post.excerpt}</p>
                  <Button variant="ghost" asChild className="text-jcred hover:text-jcred/80 p-0">
                    <Link to={`/blog/${post.id}`}>
                      Lire plus <ArrowLeft className="ml-1 h-4 w-4 rotate-180" />
                    </Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;
