
import React, { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import ManufacturerLogos from '@/components/ManufacturerLogos';
import ExpertiseSection from '@/components/ExpertiseSection';
import EnergySolutionsSection from '@/components/EnergySolutionsSection';
import AboutSection from '@/components/AboutSection';
import ReferencesSection from '@/components/ReferencesSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import ProjectsGallerySection from '@/components/ProjectsGallerySection';
import BlogSection from '@/components/BlogSection';
import FAQSection from '@/components/FAQSection';

const Index = () => {
  // Scroll to section if URL has hash
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const element = document.getElementById(hash.substring(1));
      if (element) {
        // Delay to ensure all elements are properly loaded
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 500);
      }
    }
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <HeroSection />
      <ManufacturerLogos />
      <ExpertiseSection />
      <EnergySolutionsSection />
      <ProjectsGallerySection />
      <AboutSection />
      <ReferencesSection />
      <BlogSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default Index;
