
import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center">
      <img 
        src="/lovable-uploads/8152ca08-70c9-4bae-8dca-94898cf7f5b8.png" 
        alt="JC Automation Logo" 
        className="h-10 sm:h-12 w-auto"
      />
    </div>
  );
};

export default Logo;
