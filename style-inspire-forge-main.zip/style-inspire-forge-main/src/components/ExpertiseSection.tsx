
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight } from 'lucide-react';

type ServiceCardProps = {
  title: string;
  description: string;
  icon: React.ReactNode;
  features: string[];
  delay: number;
};

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, features, delay }) => {
  return (
    <Card className="service-card animate-slide-in overflow-hidden border-gray-200 h-full transition-all hover:border-jcred/30 hover:shadow-lg" style={{ animationDelay: `${delay}s` }}>
      <CardContent className="p-6 flex flex-col h-full">
        <div className="w-14 h-14 bg-gradient-to-br from-jcred/10 to-jcred/20 flex items-center justify-center rounded-full mb-4 text-jcred">
          {icon}
        </div>
        <h3 className="text-xl font-semibold mb-2 text-jcdarkgray">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        
        <div className="mt-auto">
          {features.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-medium text-jcdarkgray mb-2">Caractéristiques</h4>
              <div className="flex flex-wrap gap-2">
                {features.map((feature, idx) => (
                  <Badge key={idx} variant="outline" className="bg-gray-50 text-jcdarkgray font-normal">
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          <div className="flex items-center text-jcred text-sm font-medium cursor-pointer hover:underline transition-colors mt-2">
            En savoir plus <ArrowRight className="ml-1 h-3 w-3" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const ExpertiseSection = () => {
  // Icons as simple JSX for services
  const electricalIcon = (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    </svg>
  );
  
  const automationIcon = (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  );
  
  const energyIcon = (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
    </svg>
  );
  
  const supervisoryIcon = (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
  );
  
  const controlIcon = (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
    </svg>
  );
  
  const protectionIcon = (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.618 5.984A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016zM12 9v2m0 4h.01" />
    </svg>
  );

  const services = [
    {
      title: "Automatisme Industriel",
      description: "Étude et réalisation de solutions d'automatisme industriel, régulation et conduite de process.",
      icon: automationIcon,
      features: ["PLC Programming", "Process Control", "SCADA Systems", "Industry 4.0"],
      delay: 0.1
    },
    {
      title: "Systèmes de Supervision",
      description: "Interface homme-machine et logiciels de supervision pour contrôle optimal des processus.",
      icon: supervisoryIcon,
      features: ["HMI Development", "Real-time Monitoring", "Data Visualization", "Remote Access"],
      delay: 0.2
    },
    {
      title: "Automates Programmables",
      description: "Commande et contrôle des processus industriels et machines automatisées.",
      icon: controlIcon,
      features: ["Siemens", "Allen Bradley", "Schneider Electric", "Omron"],
      delay: 0.3
    },
    {
      title: "Gestion de l'Énergie",
      description: "Audit énergétique et intégration des systèmes de gestion d'énergie pour optimisation des coûts.",
      icon: energyIcon,
      features: ["Energy Monitoring", "Cost Optimization", "Renewable Integration", "Efficiency Analysis"],
      delay: 0.4
    },
    {
      title: "Solutions de Variation",
      description: "Intégration d'applications de variation de vitesse et solutions solaires adaptées.",
      icon: electricalIcon,
      features: ["VFD Installation", "Motor Control", "Solar Solutions", "Power Quality"],
      delay: 0.5
    },
    {
      title: "Protection Contre Surtensions",
      description: "Solutions de protection directe et indirecte contre la foudre et les surtensions.",
      icon: protectionIcon,
      features: ["Surge Protection", "Lightning Protection", "Equipment Safety", "Risk Assessment"],
      delay: 0.6
    }
  ];

  return (
    <section id="expertise" className="bg-gray-50 py-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Domaines d'<span className="text-jcred">Expertise</span>
          </h2>
          <div className="w-24 h-1 bg-jcred mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            JC Automation offre des solutions complètes en automatisme industriel, de la conception à l'installation et la maintenance.
            Notre expertise technique garantit des systèmes fiables et performants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              description={service.description}
              icon={service.icon}
              features={service.features}
              delay={service.delay}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExpertiseSection;
