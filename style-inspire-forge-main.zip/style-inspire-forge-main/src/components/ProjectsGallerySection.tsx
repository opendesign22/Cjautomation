
import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Battery, Sun, Wind, BoltIcon,
  ArrowRight
} from 'lucide-react';
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const ProjectCase = ({ title, description, icon, delay = 0 }) => {
  return (
    <div 
      className="bg-white rounded-lg border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-all animate-slide-in" 
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        {icon}
      </div>
      <div className="p-6">
        <h3 className="font-bold text-lg mb-2 text-jcdarkgray">{title}</h3>
        <p className="text-gray-600 text-sm">{description}</p>
      </div>
    </div>
  );
};

// Project images with industrial themes
const projectImages = [
  {
    url: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&w=800&q=80",
    title: "Automatisation industrielle"
  },
  {
    url: "https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?auto=format&fit=crop&w=800&q=80",
    title: "Solutions énergétiques"
  },
  {
    url: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80",
    title: "Gestion des processus"
  },
  {
    url: "https://images.unsplash.com/photo-1510563800743-aed236490d08?auto=format&fit=crop&w=800&q=80",
    title: "Contrôle qualité"
  },
  {
    url: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800&q=80",
    title: "Optimisation de la production"
  }
];

const ProjectsGallerySection = () => {
  const projects = [
    {
      title: "Automatisme Industriel avancé",
      description: "Mise en place d'un système d'automatisme de dernière génération pour une usine de production agroalimentaire",
      icon: <BoltIcon className="h-12 w-12 text-jcred" />
    },
    {
      title: "Gestion intelligente de l'énergie",
      description: "Installation d'un système de gestion énergétique permettant 30% d'économies pour un complexe industriel",
      icon: <Battery className="h-12 w-12 text-jcred" />
    },
    {
      title: "Solutions d'énergie renouvelable",
      description: "Intégration de systèmes solaires avec l'infrastructure existante d'un site de production",
      icon: <Sun className="h-12 w-12 text-jcred" />
    },
    {
      title: "Optimisation des installations électriques",
      description: "Rénovation complète d'installations électriques pour améliorer la sécurité et l'efficacité",
      icon: <Wind className="h-12 w-12 text-jcred" />
    }
  ];

  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12 animate-slide-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Nos <span className="text-jcred">Réalisations</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Découvrez nos projets d'automatisme industriel et d'efficacité énergétique 
            qui démontrent notre expertise dans divers secteurs.
          </p>
        </div>

        {/* Image carousel of industrial projects */}
        <div className="mb-16 px-4 md:px-12">
          <Carousel 
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent>
              {projectImages.map((image, index) => (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                  <div className="p-1">
                    <div className="overflow-hidden rounded-lg shadow-md bg-white">
                      <div 
                        className="h-64 bg-cover bg-center" 
                        style={{ backgroundImage: `url("${image.url}")` }}
                      >
                      </div>
                      <div className="p-4">
                        <h3 className="font-medium text-jcdarkgray">{image.title}</h3>
                        <div className="mt-2">
                          <Button variant="ghost" size="sm" className="text-jcred hover:text-jcred/80 p-0">
                            Voir le projet <ArrowRight className="h-4 w-4 ml-1"/>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="hidden md:block">
              <CarouselPrevious className="left-2" />
              <CarouselNext className="right-2" />
            </div>
          </Carousel>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {projects.map((project, index) => (
            <ProjectCase 
              key={index} 
              title={project.title}
              description={project.description}
              icon={project.icon}
              delay={0.1 * (index + 1)}
            />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button className="bg-jcred hover:bg-red-700 text-white">
            Voir tous nos projets
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsGallerySection;
