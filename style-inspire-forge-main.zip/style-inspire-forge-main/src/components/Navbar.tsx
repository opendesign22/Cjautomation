
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import Logo from './Logo';
import { ArrowRight, Menu } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    document.addEventListener('scroll', handleScroll);
    return () => {
      document.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const toggleMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const navigateTo = (id: string) => {
    setMobileMenuOpen(false);
    
    // Check if we're already on the homepage
    if (window.location.pathname === '/') {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // Navigate to homepage with hash
      navigate(`/#${id}`);
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Link to="/">
            <Logo />
          </Link>

          {/* Desktop Navigation with ShadCn NavigationMenu */}
          <div className="hidden md:flex items-center space-x-4">
            <NavigationMenu className="hidden md:flex">
              <NavigationMenuList>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    onClick={() => navigateTo('expertise')}
                  >
                    {t('nav.expertise')}
                  </NavigationMenuLink>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    onClick={() => navigateTo('energy-solutions')}
                  >
                    {t('nav.energy-solutions')}
                  </NavigationMenuLink>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    onClick={() => navigateTo('about')}
                  >
                    {t('nav.about')}
                  </NavigationMenuLink>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    onClick={() => navigateTo('references')}
                  >
                    {t('nav.references')}
                  </NavigationMenuLink>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    asChild
                  >
                    <Link to="/blog">{t('nav.blog')}</Link>
                  </NavigationMenuLink>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    asChild
                  >
                    <Link to="/career">{t('nav.career') || (t('language') === 'fr' ? 'Carrières' : 'Careers')}</Link>
                  </NavigationMenuLink>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuLink 
                    className={navigationMenuTriggerStyle()} 
                    onClick={() => navigateTo('contact')}
                  >
                    {t('nav.contact')}
                  </NavigationMenuLink>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>

            <LanguageSwitcher />

            <Button 
              onClick={() => navigateTo('contact')}
              className="bg-jcred hover:bg-red-700 text-white"
            >
              {t('nav.contact-us')} <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          {/* Mobile Menu Button and Language Switcher */}
          <div className="md:hidden flex items-center space-x-2">
            <LanguageSwitcher />
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-jcdarkgray"
              onClick={toggleMenu}
              aria-label="Toggle Menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 py-4 bg-white rounded-lg shadow-lg animate-fade-in">
            <div className="flex flex-col space-y-4 px-4">
              <button 
                onClick={() => navigateTo('expertise')} 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2 border-b border-gray-100"
              >
                {t('nav.expertise')}
              </button>
              <button 
                onClick={() => navigateTo('energy-solutions')} 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2 border-b border-gray-100"
              >
                {t('nav.energy-solutions')}
              </button>
              <button 
                onClick={() => navigateTo('about')} 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2 border-b border-gray-100"
              >
                {t('nav.about')}
              </button>
              <button 
                onClick={() => navigateTo('references')} 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2 border-b border-gray-100"
              >
                {t('nav.references')}
              </button>
              <Link 
                to="/blog" 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2 border-b border-gray-100"
                onClick={() => setMobileMenuOpen(false)}
              >
                {t('nav.blog')}
              </Link>
              <Link 
                to="/career" 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2 border-b border-gray-100"
                onClick={() => setMobileMenuOpen(false)}
              >
                {t('nav.career') || (t('language') === 'fr' ? 'Carrières' : 'Careers')}
              </Link>
              <button 
                onClick={() => navigateTo('contact')} 
                className="text-jcdarkgray hover:text-jcred transition-colors py-2"
              >
                {t('nav.contact')}
              </button>
              <Button 
                onClick={() => navigateTo('contact')}
                className="bg-jcred hover:bg-red-700 text-white w-full mt-2"
              >
                {t('nav.contact-us')} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Navbar;
