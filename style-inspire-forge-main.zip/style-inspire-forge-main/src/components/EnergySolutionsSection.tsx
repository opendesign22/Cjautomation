
import React from 'react';
import { CirclePower, ZapOff, Cable, Database, CircleSlash, ThermometerSun } from 'lucide-react';
import { Button } from '@/components/ui/button';

const EnergySolutionsSection = () => {
  const features = [
    { 
      text: "Équilibrage dynamique des phases", 
      icon: <CirclePower className="h-5 w-5 text-jcred" /> 
    },
    { 
      text: "Filtration des harmoniques", 
      icon: <Database className="h-5 w-5 text-jcred" /> 
    },
    { 
      text: "Résoudre les problèmes de microcoupures", 
      icon: <ZapOff className="h-5 w-5 text-jcred" /> 
    },
    { 
      text: "Réduire le courant du neutre", 
      icon: <Cable className="h-5 w-5 text-jcred" /> 
    },
    { 
      text: "Réduction des pertes dues à l'effet Joule", 
      icon: <ThermometerSun className="h-5 w-5 text-jcred" /> 
    },
    { 
      text: "Stabiliser la tension du réseau triphasé", 
      icon: <CircleSlash className="h-5 w-5 text-jcred" /> 
    }
  ];

  return (
    <section id="energy-solutions" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-in" style={{ animationDelay: '0.3s' }}>
            <div className="mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Offre d'<span className="text-jcred">Expertise</span> en Efficacité Énergétique
              </h2>
              <div className="w-24 h-1 bg-jcred mb-6"></div>
              <p className="text-gray-600">
                Dans le cadre de l'efficacité énergétique de vos installations électriques, et afin 
                d'améliorer l'indice d'efficacité énergétique (IEE) de chaque site de production,
                notre fabricant vous offre une nouvelle technologie innovante à savoir :
              </p>
              <p className="text-gray-600 mt-4 font-medium">
                C'est un système de puissance qui assure à la fois les fonctions suivantes :
              </p>
            </div>

            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 p-2 bg-gray-50 rounded-full mr-4">
                    {feature.icon}
                  </div>
                  <p className="text-gray-700 pt-1">{feature.text}</p>
                </div>
              ))}
            </div>
            
            <div className="mt-8">
              <p className="font-medium text-jcdarkgray mb-4">
                La gamme de produit conçu à partir de 400A jusqu'à 5000A
              </p>
              <p className="text-gray-600">
                Nous sommes à votre disposition pour vous accompagner dans vos projets d'efficacité 
                énergétique pour se confronter au défis de la compétitivité industrielle.
              </p>
              <Button className="mt-6 bg-jcred hover:bg-red-700 text-white">
                Demander un devis
              </Button>
            </div>
          </div>

          <div className="space-y-6 animate-slide-in" style={{ animationDelay: '0.5s' }}>
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-8 shadow-sm">
              <div className="flex flex-col items-center text-center">
                <div className="bg-red-50 p-4 rounded-full mb-4">
                  <ThermometerSun className="h-12 w-12 text-jcred" />
                </div>
                <h3 className="text-xl font-bold text-jcdarkgray mb-2">Solutions d'Optimisation Énergétique</h3>
                <p className="text-gray-600">
                  Notre technologie innovante permet de réduire significativement votre consommation 
                  énergétique tout en améliorant la qualité et la stabilité de votre réseau électrique.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 flex flex-col items-center">
                <div className="text-jcred font-bold text-xl mb-2">400A-5000A</div>
                <p className="text-center text-xs text-gray-500">Gamme de produits disponibles</p>
              </div>
              <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 flex flex-col items-center">
                <div className="text-jcred font-bold text-xl mb-2">20+ ans</div>
                <p className="text-center text-xs text-gray-500">D'expertise en automation</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EnergySolutionsSection;
