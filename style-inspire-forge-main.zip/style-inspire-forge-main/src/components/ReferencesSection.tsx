
import React from 'react';
import { Building, Factory, Cpu, Shirt, Apple } from 'lucide-react';

type ReferenceCategory = {
  title: string;
  items: string[];
  icon: JSX.Element;
};

const ReferenceCard: React.FC<ReferenceCategory & { delay: number }> = ({ title, items, icon, delay }) => {
  return (
    <div className="animate-slide-in bg-white rounded-lg shadow-sm p-6 border border-gray-100" style={{ animationDelay: `${delay}s` }}>
      <div className="flex items-center mb-4">
        <div className="p-2 bg-red-50 rounded-full mr-3">
          {icon}
        </div>
        <h3 className="text-jcred font-semibold uppercase text-sm">{title}</h3>
      </div>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="text-gray-600">{item}</li>
        ))}
      </ul>
    </div>
  );
};

const ReferencesSection = () => {
  const categories: ReferenceCategory[] = [
    {
      title: "Infrastructure",
      items: [
        "MAROC TELECOM",
        "ORMVA G.L.D.S (stations de Pompage)",
        "ONEP FES (Station de prétraitement)"
      ],
      icon: <Building className="h-5 w-5 text-jcred" />
    },
    {
      title: "Industrie",
      items: [
        "MIS",
        "Maghreb Steel",
        "Longlafer",
        "MOULIN AIN ATIQ",
        "OCPJORF et SAFI"
      ],
      icon: <Factory className="h-5 w-5 text-jcred" />
    },
    {
      title: "Plasturgies",
      items: [
        "OFFSET POLYPLAST"
      ],
      icon: <Cpu className="h-5 w-5 text-jcred" />
    },
    {
      title: "Textile",
      items: [
        "SOFT COLOR"
      ],
      icon: <Shirt className="h-5 w-5 text-jcred" />
    },
    {
      title: "Agroalimentaire",
      items: [
        "CENTRALE LAITIERE"
      ],
      icon: <Apple className="h-5 w-5 text-jcred" />
    }
  ];

  return (
    <section id="references" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Nos <span className="text-jcred">Références</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Nous travaillons avec des entreprises leaders dans divers secteurs industriels,
            témoignant de notre expertise et de notre fiabilité.
          </p>
        </div>

        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          style={{
            backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(227, 30, 36, 0.03) 0%, transparent 70%)'
          }}
        >
          {categories.map((category, index) => (
            <ReferenceCard 
              key={index} 
              title={category.title} 
              items={category.items} 
              icon={category.icon}
              delay={0.1 * (index + 1)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ReferencesSection;
