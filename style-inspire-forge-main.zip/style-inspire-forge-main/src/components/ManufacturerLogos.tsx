
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

const ManufacturerLogos = () => {
  const { t } = useLanguage();
  
  const logos = [
    {
      name: 'Allen Bradley',
      src: 'https://www.rockwellautomation.com/content/dam/rockwell-automation/sites/images/logos/2019_Logo_AllenBradley_rgb.svg',
      width: 160
    },
    {
      name: 'Rockwell Automation',
      src: 'https://www.rockwellautomation.com/content/dam/rockwell-automation/sites/images/logos/2019_Logo_rgb_RA_Bug-LeftText_color.svg',
      width: 200
    },
    {
      name: 'Citect',
      src: '/lovable-uploads/945c9f99-9115-4b5a-a041-2462fce51240.png',
      width: 140
    },
    {
      name: 'Schneider Electric',
      src: 'https://upload.wikimedia.org/wikipedia/commons/6/6c/Schneider_Electric_2007.svg',
      width: 180
    },
    {
      name: 'Siemens',
      src: 'https://upload.wikimedia.org/wikipedia/commons/5/5f/Siemens-logo.svg',
      width: 130
    },
    {
      name: 'ABB',
      src: 'https://upload.wikimedia.org/wikipedia/commons/0/00/ABB_logo.svg',
      width: 100
    },
    {
      name: 'SECOMIC',
      src: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625',
      width: 150
    },
    {
      name: 'Omron',
      src: 'https://upload.wikimedia.org/wikipedia/commons/2/2a/OMRON_Logo.svg',
      width: 150
    },
    {
      name: 'Mitsubishi Electric',
      src: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Mitsubishi_Electric_logo.svg/2560px-Mitsubishi_Electric_logo.svg.png',
      width: 180
    },
    {
      name: 'Beckhoff',
      src: 'https://upload.wikimedia.org/wikipedia/commons/0/0d/Beckhoff_Logo.svg',
      width: 160
    },
    {
      name: 'Phoenix Contact',
      src: 'https://upload.wikimedia.org/wikipedia/commons/9/91/PhoenixContact_Logo.svg',
      width: 170
    }
  ];

  return (
    <div className="py-8 bg-white">
      <div className="container mx-auto px-4">
        <h3 className="text-center text-gray-600 mb-8">{t('hero.partners')}</h3>
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
          {logos.map((logo, index) => (
            <div 
              key={index} 
              className="flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-300 partner-logo animate-soft-pulse"
              style={{ 
                height: '50px', 
                animationDelay: `${index * 0.2}s` 
              }}
            >
              <img 
                src={logo.src} 
                alt={`${logo.name} logo`} 
                style={{ maxHeight: '100%', width: 'auto', maxWidth: logo.width + 'px' }} 
                className="object-contain"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ManufacturerLogos;
