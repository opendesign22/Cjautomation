
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const HeroSection = () => {
  const { t } = useLanguage();

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToNextSection = () => {
    const expertise = document.getElementById('expertise');
    if (expertise) {
      expertise.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Service images for the floating cards
  const serviceImages = [
    {
      title: "Automatisme",
      icon: "/lovable-uploads/7a8f295e-e51a-4dd3-a0ab-10b546e54932.png",
      position: "top-1/4 -right-12 rotate-6"
    },
    {
      title: "Electricité",
      icon: "/lovable-uploads/a2640d43-5f99-49ed-a91d-d68a545d556b.png",
      position: "bottom-1/4 -right-16 -rotate-12"
    }
  ];

  return (
    <section className="relative min-h-screen flex items-center pt-16 pb-20 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50 to-gray-100"></div>
        <div 
          className="absolute inset-0 opacity-10"
          style={{ 
            backgroundImage: `url("https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1920&q=80")`,
            backgroundSize: 'cover', 
            backgroundPosition: 'center',
            mixBlendMode: 'overlay'
          }}
        ></div>
        
        {/* Abstract shape decorations */}
        <div className="absolute top-1/3 left-10 w-64 h-64 rounded-full bg-jcred/5 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-10 w-96 h-96 rounded-full bg-blue-500/5 blur-3xl"></div>
        
        <div className="curve-decoration hidden lg:block" style={{ 
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(227, 30, 36, 0.05) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(157, 157, 156, 0.1) 0%, transparent 100%)' 
        }}></div>
      </div>
      
      {/* Main content */}
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left column - Text content */}
          <div className="animate-slide-in" style={{ animationDelay: '0.2s' }}>
            <div className="mb-4 inline-flex items-center rounded-full border border-jcred/20 bg-jcred/10 px-4 py-1.5 text-sm font-medium text-jcred">
              <span className="mr-1 text-xs">✦</span> JC Automation
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-jcdarkgray mb-6 leading-tight">
              <span className="text-jcred">Automatisme</span> {t('hero.title')}
            </h1>
            
            <p className="text-lg text-gray-600 mb-8 max-w-lg">
              {t('hero.subtitle')}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={scrollToContact} 
                className="bg-jcred hover:bg-red-700 text-white px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
              >
                {t('hero.cta')} <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => document.getElementById('expertise')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-jcgray text-jcdarkgray hover:text-jcred px-8 py-6 text-lg hover:bg-jcred/5 transition-all duration-300"
              >
                {t('hero.expertise')}
              </Button>
            </div>
            
            {/* Stats display */}
            <div className="mt-12 grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="p-4 border border-gray-100 bg-white/80 rounded-lg shadow-sm">
                <div className="text-3xl font-bold text-jcred">25+</div>
                <div className="text-sm text-gray-500">Années d'expérience</div>
              </div>
              <div className="p-4 border border-gray-100 bg-white/80 rounded-lg shadow-sm">
                <div className="text-3xl font-bold text-jcred">500+</div>
                <div className="text-sm text-gray-500">Projets complétés</div>
              </div>
              <div className="p-4 border border-gray-100 bg-white/80 rounded-lg shadow-sm hidden md:block">
                <div className="text-3xl font-bold text-jcred">100%</div>
                <div className="text-sm text-gray-500">Satisfaction client</div>
              </div>
            </div>
          </div>
          
          {/* Right column - Image */}
          <div className="hidden lg:flex justify-center relative">
            <div className="relative animate-slide-in" style={{ animationDelay: '0.5s' }}>
              {/* Glowing effect behind image */}
              <div className="absolute -inset-4 rounded-full bg-gradient-to-br from-jcred/20 to-jcgray/20 blur-xl opacity-70 animate-pulse"></div>
              
              {/* Main image */}
              <img 
                src="/lovable-uploads/8152ca08-70c9-4bae-8dca-94898cf7f5b8.png" 
                alt="JC Automation" 
                className="w-full max-w-md relative z-10 rounded-lg shadow-xl"
              />
              
              {/* Floating service images */}
              {serviceImages.map((service, index) => (
                <div 
                  key={index} 
                  className={`absolute ${service.position} z-20 animate-fade-in`}
                  style={{ animationDelay: `${0.8 + index * 0.2}s` }}
                >
                  <div className="bg-white rounded-lg shadow-lg p-3 flex items-center gap-3 transform hover:scale-105 transition-transform">
                    <img src={service.icon} alt={service.title} className="w-12 h-12 object-contain" />
                    <span className="font-medium text-jcdarkgray">{service.title}</span>
                  </div>
                </div>
              ))}
              
              {/* Accent decorations */}
              <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-jcred/10 rounded-full blur-md"></div>
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-blue-500/10 rounded-full blur-md"></div>
            </div>
          </div>
        </div>
        
        {/* Scroll down indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center animate-bounce cursor-pointer" onClick={scrollToNextSection}>
          <span className="text-sm text-gray-500 mb-2">Scroll Down</span>
          <ChevronDown className="h-6 w-6 text-jcred" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
