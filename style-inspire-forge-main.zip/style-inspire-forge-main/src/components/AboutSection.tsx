
import React from 'react';
import { Button } from '@/components/ui/button';

const AboutSection = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1 animate-slide-in" style={{ animationDelay: '0.2s' }}>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Qui <span className="text-jcred">Sommes-Nous</span> ?
            </h2>
            <div className="w-16 h-1 bg-jcred mb-6"></div>
            <p className="text-gray-600 mb-6 text-lg">
              Intégrateur de solutions sur mesure en électricité et automatisme, 
              <strong className="text-jcdarkgray"> JC Automation</strong> s'engage à vos côtés pour vous accompagner 
              dans l'étude, conception et la mise en œuvre de vos projets.
            </p>
            <p className="text-gray-600 mb-6">
              Une expérience de 20 ans dans ce domaine et une équipe professionnelle, 
              dynamique, créative, impliquée et à l'écoute de vos besoins. 
              <strong className="text-jcdarkgray"> JC Automation</strong> met aujourd'hui ce savoir-faire à la disposition 
              des industriels quelque soit leur marché, la typologie ou la complexité de leurs projets.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
              <div className="border-l-4 border-jcred pl-4">
                <h4 className="font-semibold text-jcdarkgray mb-2">Notre Mission</h4>
                <p className="text-gray-600 text-sm">Fournir des solutions d'automatisation innovantes et fiables pour améliorer l'efficacité opérationnelle.</p>
              </div>
              <div className="border-l-4 border-jcred pl-4">
                <h4 className="font-semibold text-jcdarkgray mb-2">Notre Vision</h4>
                <p className="text-gray-600 text-sm">Devenir le partenaire de référence en automatisation industrielle et gestion d'énergie.</p>
              </div>
            </div>
            
            <Button onClick={scrollToContact} className="bg-jcred hover:bg-red-700 text-white px-6 py-2">
              Collaborons ensemble
            </Button>
          </div>
          
          <div className="order-1 lg:order-2 animate-slide-in flex justify-center" style={{ animationDelay: '0.4s' }}>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-tr from-jcred/10 to-jcgray/10 rounded-lg blur-xl"></div>
              <div className="relative bg-white p-6 rounded-lg shadow-lg">
                <div className="aspect-square w-full max-w-md bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center rounded-lg overflow-hidden relative">
                  {/* Add industrial automation background image */}
                  <div 
                    className="absolute inset-0 opacity-20" 
                    style={{ 
                      backgroundImage: 'url("https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80")',
                      backgroundSize: 'cover',
                      backgroundPosition: 'center'
                    }}
                  ></div>
                  <div className="transform relative z-10">
                    <img 
                      src="/lovable-uploads/8152ca08-70c9-4bae-8dca-94898cf7f5b8.png" 
                      alt="JC Automation Logo" 
                      className="w-full max-w-xs p-8"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
