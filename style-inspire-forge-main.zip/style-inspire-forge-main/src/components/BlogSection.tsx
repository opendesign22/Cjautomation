
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, Newspaper } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { blogPosts } from '../pages/Blog';

type BlogPostProps = {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  category: string;
  delay: number;
};

const BlogPost: React.FC<BlogPostProps> = ({ id, title, excerpt, image, date, category, delay }) => {
  return (
    <div 
      className="blog-card overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all animate-slide-in"
      style={{ animationDelay: `${delay}s` }}
    >
      <Link to={`/blog/${id}`}>
        <div 
          className="h-48 bg-cover bg-center" 
          style={{ backgroundImage: `url("${image}")` }}
        ></div>
      </Link>
      <div className="p-5">
        <div className="flex justify-between items-center mb-3">
          <Badge variant="outline" className="bg-gray-50 text-jcdarkgray">
            {category}
          </Badge>
          <span className="text-sm text-gray-500">{date}</span>
        </div>
        <Link to={`/blog/${id}`}>
          <h3 className="font-bold text-lg mb-2 text-jcdarkgray hover:text-jcred transition-colors">{title}</h3>
        </Link>
        <p className="text-gray-600 text-sm mb-4">{excerpt}</p>
        <Button variant="ghost" asChild className="text-jcred hover:text-jcred/80 p-0">
          <Link to={`/blog/${id}`}>
            Lire plus <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  );
};

const BlogSection = () => {
  return (
    <section id="blog" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12 animate-slide-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Notre <span className="text-jcred">Blog</span>
          </h2>
          <div className="w-24 h-1 bg-jcred mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Restez informé des dernières tendances et innovations dans le domaine de l'automatisme industriel
            et des solutions énergétiques.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <BlogPost
              key={index}
              id={post.id}
              title={post.title}
              excerpt={post.excerpt}
              image={post.image}
              date={post.date}
              category={post.category}
              delay={0.1 * (index + 1)}
            />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Button asChild className="bg-jcred hover:bg-red-700 text-white">
            <Link to="/blog">
              Voir tous les articles <Newspaper className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
